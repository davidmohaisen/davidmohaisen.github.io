//
//  main.m
//  meetup5
//
//  Created by Denis on 10/22/10.
//  Copyright 2010 Scientist of Fortune. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
